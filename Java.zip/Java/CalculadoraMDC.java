public class CalculadoraMDC {

    /**
     * Método 1: Calcula o MDC iterativamente usando o Algoritmo de Euclides.
     * Esta é a forma mais recomendada, pois não consome memória extra.
     * 
     * @param a O primeiro número inteiro.
     * @param b O segundo número inteiro.
     * @return O MDC de a e b.
     */
    public static int calcularMDC(int a, int b) {
        // Garantimos que estamos lidando com valores positivos
        a = Math.abs(a);
        b = Math.abs(b);
        
        // O laço continua até que o divisor (b) se torne zero
        while (b != 0) {
            int resto = a % b; // Pega o resto da divisão
            a = b;             // O divisor passa a ser o dividendo
            b = resto;         // O resto passa a ser o novo divisor
        }
        
        // Quando b é zero, 'a' contém o MDC
        return a;
    }

    /**
     * Método 2: Calcula o MDC usando recursividade.
     * Mais curto e elegante, faz exatamente a mesma lógica matemática.
     */
    public static int calcularMDCRecursivo(int a, int b) {
        // Condição de parada: se o resto for zero, retornamos o absoluto de 'a'
        if (b == 0) {
            return Math.abs(a);
        }
        // Chamada recursiva passando 'b' e o resto de 'a' por 'b'
        return calcularMDCRecursivo(b, a % b);
    }

    public static void main(String[] args) {
        int num1 = 48;
        int num2 = 18;
        
        System.out.println("--- Máximo Divisor Comum (MDC) ---");
        
        int resultadoIterativo = calcularMDC(num1, num2);
        System.out.println("MDC de " + num1 + " e " + num2 + " (Iterativo) = " + resultadoIterativo);
        
        int num3 = 1071;
        int num4 = 462;
        int resultadoRecursivo = calcularMDCRecursivo(num3, num4);
        System.out.println("MDC de " + num3 + " e " + num4 + " (Recursivo) = " + resultadoRecursivo);
    }
}