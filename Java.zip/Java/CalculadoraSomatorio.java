import java.util.Arrays;

public class CalculadoraSomatorio {

    /**
     * Método 1: Calcula o somatório usando um laço de repetição tradicional.
     * 
     * @param numeros Um array de números (double) a serem somados.
     * @return O resultado da soma de todos os números.
     */
    public static double calcularSomatorioTradicional(double[] numeros) {
        double soma = 0; // Variável para acumular o resultado
        
        // Percorre cada número dentro do conjunto
        for (double numero : numeros) {
            soma += numero; // Adiciona o número atual à soma total
        }
        
        return soma;
    }

    /**
     * Método 2: Calcula o somatório usando Java Streams (mais moderno e conciso).
     * 
     * @param numeros Um array de números (double) a serem somados.
     * @return O resultado da soma de todos os números.
     */
    public static double calcularSomatorioStream(double[] numeros) {
        // Converte o array em uma Stream e chama a função sum()
        return Arrays.stream(numeros).sum();
    }

    public static void main(String[] args) {
        // Conjunto de números para testar
        double[] meuConjunto = {10.5, 20.0, 5.25, 4.25, 10.0};
        
        System.out.println("--- Calculadora de Somatório ---");
        System.out.println("Conjunto de números: " + Arrays.toString(meuConjunto));
        System.out.println("--------------------------------");
        
        // Testando o método tradicional
        double resultadoTradicional = calcularSomatorioTradicional(meuConjunto);
        System.out.println("Resultado (Método Tradicional): " + resultadoTradicional);
        
        // Testando o método com Streams
        double resultadoStream = calcularSomatorioStream(meuConjunto);
        System.out.println("Resultado (Método Stream): " + resultadoStream);
    }
}