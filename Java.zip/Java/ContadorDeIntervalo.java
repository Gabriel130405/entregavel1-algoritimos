import java.util.Arrays;

public class ContadorDeIntervalo {

    /**
     * Conta quantos valores no conjunto de dados estão entre o primeiro elemento e N.
     * 
     * @param dados O array contendo o conjunto de dados.
     * @return A quantidade de números que pertencem ao intervalo.
     */
    public static int contarValoresNoIntervalo(int[] dados) {
        // Validação de segurança: se o array for nulo ou vazio, retorna 0
        if (dados == null || dados.length == 0) {
            return 0;
        }

        int n = dados.length;          // N é a quantidade de números de entrada
        int primeiroDado = dados[0];   // O primeiro elemento do conjunto

        // Definimos o menor e o maior valor para formar o intervalo corretamente
        // Isso evita erros caso o primeiroDado seja maior que N
        int limiteInferior = Math.min(primeiroDado, n);
        int limiteSuperior = Math.max(primeiroDado, n);

        int contador = 0; // Variável para guardar quantas vezes encontramos um número válido

        // Percorre todo o conjunto de dados
        for (int valor : dados) {
            // Verifica se o valor atual está dentro do intervalo (inclusive)
            if (valor >= limiteInferior && valor <= limiteSuperior) {
                contador++;
            }
        }

        return contador;
    }

    public static void main(String[] args) {
        // Exemplo: N = 7 (tamanho do array)
        // Primeiro dado = 3
        // Intervalo de busca será entre 3 e 7.
        int[] meuConjunto = {3, 8, 1, 5, 7, 4, 10}; 
        
        System.out.println("--- Algoritmo de Contagem ---");
        System.out.println("Conjunto de dados: " + Arrays.toString(meuConjunto));
        System.out.println("N (Tamanho do conjunto): " + meuConjunto.length);
        System.out.println("Primeiro dado: " + meuConjunto[0]);
        
        int quantidade = contarValoresNoIntervalo(meuConjunto);
        
        System.out.println("\nValores encontrados no intervalo [" 
                + Math.min(meuConjunto[0], meuConjunto.length) + ", " 
                + Math.max(meuConjunto[0], meuConjunto.length) + "]: " + quantidade);
        
        // No exemplo acima, os números dentro do intervalo [3, 7] no array são: 3, 5, 7 e 4.
        // Logo, a resposta deve ser 4.
    }
}