import java.util.Arrays;

public class GeradorFibonacci {

    /**
     * Gera os primeiros N termos da sequência de Fibonacci.
     * Utiliza uma abordagem iterativa (laço de repetição), que é muito eficiente.
     * 
     * @param n A quantidade de termos desejada (N > 1).
     * @return Um array contendo a sequência.
     */
    public static long[] gerarSequencia(int n) {
        // Validação de segurança para N inválido
        if (n <= 0) {
            return new long[0];
        }
        
        // Se N for 1, retorna apenas o primeiro termo
        if (n == 1) {
            return new long[]{0};
        }
        
        // Cria um array para armazenar a sequência
        long[] sequencia = new long[n];
        
        // Definindo os dois primeiros termos obrigatórios
        sequencia[0] = 0; 
        sequencia[1] = 1; 
        
        // A partir do terceiro termo (índice 2), cada elemento é a soma dos dois anteriores
        for (int i = 2; i < n; i++) {
            sequencia[i] = sequencia[i - 1] + sequencia[i - 2];
        }
        
        return sequencia;
    }

    public static void main(String[] args) {
        // Exemplo: queremos os 15 primeiros termos
        int quantidadeDeTermos = 15;
        
        System.out.println("--- Sequência de Fibonacci ---");
        
        long[] resultado = gerarSequencia(quantidadeDeTermos);
        
        System.out.println("Os primeiros " + quantidadeDeTermos + " termos são:");
        // Arrays.toString() é uma forma prática de imprimir o array inteiro formatado
        System.out.println(Arrays.toString(resultado));
    }
}