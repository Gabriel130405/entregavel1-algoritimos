import java.util.Arrays;

public class OrdenacaoQuicksort {

    /**
     * Método principal que chama a recursão do Quicksort.
     * 
     * @param array O array a ser ordenado.
     * @param inicio O índice inicial da parte do array a ser ordenada (geralmente 0).
     * @param fim O índice final da parte do array a ser ordenada (tamanho - 1).
     */
    public static void quickSort(int[] array, int inicio, int fim) {
        if (inicio < fim) {
            // O particionamento coloca o pivô no lugar correto e retorna seu índice
            int indicePivo = particionar(array, inicio, fim);

            // Ordena recursivamente a sublista à esquerda do pivô
            quickSort(array, inicio, indicePivo - 1);
            
            // Ordena recursivamente a sublista à direita do pivô
            quickSort(array, indicePivo + 1, fim);
        }
    }

    /**
     * Método que reorganiza o array com base no pivô.
     */
    private static int particionar(int[] array, int inicio, int fim) {
        // Escolhemos o último elemento do trecho como pivô
        int pivo = array[fim];
        
        // Índice que aponta para o último elemento menor encontrado
        int i = (inicio - 1);

        // Percorre o array comparando os elementos com o pivô
        for (int j = inicio; j < fim; j++) {
            // Se o elemento atual for menor ou igual ao pivô
            if (array[j] <= pivo) {
                i++; // Avança o marcador dos elementos menores
                
                // Troca o elemento atual com o elemento no índice i
                int temp = array[i];
                array[i] = array[j];
                array[j] = temp;
            }
        }

        // Coloca o pivô na sua posição final definitiva, logo após os menores
        int temp = array[i + 1];
        array[i + 1] = array[fim];
        array[fim] = temp;

        // Retorna a posição onde o pivô ficou
        return i + 1;
    }

    public static void main(String[] args) {
        int[] meuArray = {10, 7, 8, 9, 1, 5, 42, 23, 4};
        
        System.out.println("--- Algoritmo Quicksort ---");
        System.out.println("Array original: " + Arrays.toString(meuArray));
        
        // Chamando o Quicksort passando o índice do primeiro e do último elemento
        quickSort(meuArray, 0, meuArray.length - 1);
        
        System.out.println("Array ordenado: " + Arrays.toString(meuArray));
    }
}