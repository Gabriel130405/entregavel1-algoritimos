public class VerificadorDePrimos {

    /**
     * Verifica se um número inteiro positivo é primo.
     * 
     * @param n O número a ser verificado.
     * @return true se o número for primo, false caso contrário.
     */
    public static boolean isPrime(int n) {
        // Regra base: números menores ou iguais a 1 não são primos
        if (n <= 1) {
            return false;
        }
        
        // 2 é o único número par primo
        if (n == 2) {
            return true;
        }
        
        // Se for divisível por 2 (e não for 2), não é primo
        if (n % 2 == 0) {
            return false;
        }
        
        // Verifica a divisibilidade apenas por números ímpares até a raiz quadrada de n
        for (int i = 3; i <= Math.sqrt(n); i += 2) {
            if (n % i == 0) {
                return false; // Encontrou um divisor, logo não é primo
            }
        }
        
        // Se passou por todas as verificações, é primo
        return true;
    }

    public static void main(String[] args) {
        // Testando a função com alguns exemplos
        int[] numerosParaTestar = {1, 2, 3, 4, 17, 25, 97, 100};
        
        System.out.println("--- Verificador de Números Primos ---");
        for (int num : numerosParaTestar) {
            if (isPrime(num)) {
                System.out.println(num + " é primo.");
            } else {
                System.out.println(num + " NÃO é primo.");
            }
        }
    }
}