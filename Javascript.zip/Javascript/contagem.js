/**
 * Método 1: Abordagem tradicional usando laço de repetição.
 * 
 * @param {number[]} dados O array contendo o conjunto de dados.
 * @returns {number} A quantidade de números inteiros no intervalo.
 */
function contarValoresTradicional(dados) {
    // Validação de segurança
    if (!dados || dados.length === 0) {
        return 0;
    }

    const n = dados.length;
    const primeiroDado = dados[0];

    // Definimos o menor e o maior valor para formar o intervalo corretamente
    const limiteInferior = Math.min(primeiroDado, n);
    const limiteSuperior = Math.max(primeiroDado, n);

    let contador = 0;

    for (const valor of dados) {
        // Verifica se é um número inteiro E se está dentro do intervalo
        if (Number.isInteger(valor) && valor >= limiteInferior && valor <= limiteSuperior) {
            contador++;
        }
    }

    return contador;
}

/**
 * Método 2: Abordagem funcional usando o método filter() (Mais moderno).
 * 
 * @param {number[]} dados O array contendo o conjunto de dados.
 * @returns {number} A quantidade de números inteiros no intervalo.
 */
function contarValoresFilter(dados) {
    if (!dados || dados.length === 0) return 0;

    const n = dados.length;
    const limiteInferior = Math.min(dados[0], n);
    const limiteSuperior = Math.max(dados[0], n);

    // O filter() cria um novo array apenas com os itens que passam no teste lógico
    const valoresValidos = dados.filter(valor => 
        Number.isInteger(valor) && valor >= limiteInferior && valor <= limiteSuperior
    );

    // Retornamos o tamanho do array filtrado, que é a nossa contagem
    return valoresValidos.length;
}

// Testando o código
// Exemplo: N = 7 (tamanho do array)
// Primeiro dado = 3
// Intervalo de busca será entre 3 e 7.
const meuConjunto = [3, 8.5, 1, 5, 7, 4, 10]; 

console.log("--- Algoritmo de Contagem ---");
console.log(`Conjunto de dados: [${meuConjunto.join(", ")}]`);
console.log(`N (Tamanho do conjunto): ${meuConjunto.length}`);
console.log(`Primeiro dado: ${meuConjunto[0]}`);

const limiteMin = Math.min(meuConjunto[0], meuConjunto.length);
const limiteMax = Math.max(meuConjunto[0], meuConjunto.length);
console.log(`\nBuscando valores inteiros no intervalo [${limiteMin}, ${limiteMax}]...`);

// Testando os métodos
console.log("Resultado (Tradicional): " + contarValoresTradicional(meuConjunto));
console.log("Resultado (Filter): " + contarValoresFilter(meuConjunto));