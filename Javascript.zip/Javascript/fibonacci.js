/**
 * Gera os primeiros N termos da sequência de Fibonacci.
 * Utiliza uma abordagem iterativa (laço de repetição), que é muito eficiente.
 * 
 * @param {number} n A quantidade de termos desejada (N > 1).
 * @returns {number[]} Um array contendo a sequência.
 */
function gerarFibonacci(n) {
    // Validação de segurança para N inválido
    if (n <= 0) {
        return [];
    }
    
    // Se N for 1, retorna apenas o primeiro termo
    if (n === 1) {
        return [0];
    }
    
    // Criando o array já com os dois primeiros termos obrigatórios
    const sequencia = [0, 1];
    
    // A partir do terceiro termo (índice 2), cada elemento é a soma dos dois anteriores
    for (let i = 2; i < n; i++) {
        // O método push adiciona o novo valor ao final do array
        sequencia.push(sequencia[i - 1] + sequencia[i - 2]);
    }
    
    return sequencia;
}

// Exemplo: queremos os 15 primeiros termos
const quantidadeDeTermos = 15;

console.log("--- Sequência de Fibonacci ---");

const resultado = gerarFibonacci(quantidadeDeTermos);

console.log(`Os primeiros ${quantidadeDeTermos} termos são:`);
// O método join() transforma o array em uma string separada por vírgulas para facilitar a leitura
console.log(resultado.join(", "));