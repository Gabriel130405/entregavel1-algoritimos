/**
 * Método 1: Calcula o MDC iterativamente usando o Algoritmo de Euclides.
 * Mais recomendado para evitar o excesso de chamadas na pilha de execução.
 * 
 * @param {number} a O primeiro número inteiro.
 * @param {number} b O segundo número inteiro.
 * @returns {number} O MDC de a e b.
 */
function calcularMDC(a, b) {
    // Garantimos que estamos lidando com valores positivos
    a = Math.abs(a);
    b = Math.abs(b);
    
    // O laço continua até que o divisor (b) se torne zero
    while (b !== 0) {
        let resto = a % b; // Pega o resto da divisão
        a = b;             // O divisor passa a ser o dividendo
        b = resto;         // O resto passa a ser o novo divisor
    }
    
    // Quando b é zero, 'a' contém o MDC
    return a;
}

/**
 * Método 2: Calcula o MDC usando recursividade.
 * Código mais curto e matemático, usando a própria função para o loop.
 * 
 * @param {number} a O primeiro número inteiro.
 * @param {number} b O segundo número inteiro.
 * @returns {number} O MDC de a e b.
 */
function calcularMDCRecursivo(a, b) {
    // Condição de parada: se o resto for zero, retornamos o absoluto de 'a'
    if (b === 0) {
        return Math.abs(a);
    }
    
    // Chamada recursiva passando 'b' e o resto de 'a' por 'b'
    return calcularMDCRecursivo(b, a % b);
}

// Testando o código
const num1 = 48;
const num2 = 18;

console.log("--- Máximo Divisor Comum (MDC) ---");

const resultadoIterativo = calcularMDC(num1, num2);
console.log(`MDC de ${num1} e ${num2} (Iterativo) = ${resultadoIterativo}`);

const num3 = 1071;
const num4 = 462;
const resultadoRecursivo = calcularMDCRecursivo(num3, num4);
console.log(`MDC de ${num3} e ${num4} (Recursivo) = ${resultadoRecursivo}`);