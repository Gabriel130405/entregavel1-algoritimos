/**
 * Verifica se um número inteiro positivo é primo.
 * 
 * @param {number} n O número a ser verificado.
 * @returns {boolean} true se o número for primo, false caso contrário.
 */
function isPrime(n) {
    // Regra base: números menores ou iguais a 1 não são primos
    if (n <= 1) {
        return false;
    }
    
    // 2 é o único número par primo
    if (n === 2) {
        return true;
    }
    
    // Se for divisível por 2 (e não for 2), não é primo
    if (n % 2 === 0) {
        return false;
    }
    
    // Verifica a divisibilidade apenas por números ímpares até a raiz quadrada de n
    for (let i = 3; i <= Math.sqrt(n); i += 2) {
        if (n % i === 0) {
            return false; // Encontrou um divisor, logo não é primo
        }
    }
    
    // Se passou por todas as verificações, é primo
    return true;
}

// Testando a função com alguns exemplos
const numerosParaTestar = [1, 2, 3, 4, 17, 25, 97, 100];

console.log("--- Verificador de Números Primos ---");
numerosParaTestar.forEach(num => {
    if (isPrime(num)) {
        console.log(`${num} é primo.`);
    } else {
        console.log(`${num} NÃO é primo.`);
    }
});