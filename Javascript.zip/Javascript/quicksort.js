/**
 * Método 1: Quicksort Tradicional (In-place)
 * Ordena o array original modificando as posições dos elementos.
 * 
 * @param {number[]} array O array a ser ordenado.
 * @param {number} inicio Índice inicial (padrão é 0).
 * @param {number} fim Índice final (padrão é o último elemento).
 */
function quickSortTradicional(array, inicio = 0, fim = array.length - 1) {
    if (inicio < fim) {
        // Encontra a posição correta do pivô
        const indicePivo = particionar(array, inicio, fim);

        // Chama a função recursivamente para os dois lados do pivô
        quickSortTradicional(array, inicio, indicePivo - 1);
        quickSortTradicional(array, indicePivo + 1, fim);
    }
    return array;
}

function particionar(array, inicio, fim) {
    const pivo = array[fim]; // Escolhemos o último elemento como pivô
    let i = inicio - 1;      // Marcador para os elementos menores que o pivô

    for (let j = inicio; j < fim; j++) {
        if (array[j] <= pivo) {
            i++;
            // Troca os elementos de lugar usando destructuring (recurso do ES6)
            [array[i], array[j]] = [array[j], array[i]];
        }
    }

    // Coloca o pivô na sua posição final correta
    [array[i + 1], array[fim]] = [array[fim], array[i + 1]];
    
    return i + 1;
}

/**
 * Método 2: Quicksort Funcional (Estilo ES6+)
 * Não altera o array original, retorna um novo array ordenado.
 * 
 * @param {number[]} array O array a ser ordenado.
 */
function quickSortFuncional(array) {
    // Condição de parada da recursão
    if (array.length <= 1) {
        return array;
    }

    const pivo = array[array.length - 1]; // Pega o último elemento
    const esquerda = [];
    const direita = [];

    // Separa os elementos menores e maiores que o pivô
    for (let i = 0; i < array.length - 1; i++) {
        if (array[i] < pivo) {
            esquerda.push(array[i]);
        } else {
            direita.push(array[i]);
        }
    }

    // Usa o Spread Operator (...) para juntar a esquerda ordenada, o pivô e a direita ordenada
    return [...quickSortFuncional(esquerda), pivo, ...quickSortFuncional(direita)];
}

// Testando os códigos
const array1 = [10, 7, 8, 9, 1, 5, 42, 23, 4];
const array2 = [...array1]; // Criando uma cópia para o segundo teste

console.log("--- Algoritmo Quicksort ---");

console.log("Método Tradicional (In-place):");
console.log("Antes:", array1.join(", "));
quickSortTradicional(array1);
console.log("Depois:", array1.join(", "));

console.log("\n---------------------------\n");

console.log("Método Funcional:");
console.log("Antes:", array2.join(", "));
const resultadoFuncional = quickSortFuncional(array2);
console.log("Depois:", resultadoFuncional.join(", "));