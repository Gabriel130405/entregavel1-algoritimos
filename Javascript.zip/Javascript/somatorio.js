/**
 * Método 1: Calcula o somatório usando um laço de repetição tradicional.
 * 
 * @param {number[]} numeros Um array de números a serem somados.
 * @returns {number} O resultado da soma de todos os números.
 */
function calcularSomatorioTradicional(numeros) {
    let soma = 0; // Variável para acumular o resultado
    
    // Percorre cada número dentro do array
    for (let i = 0; i < numeros.length; i++) {
        soma += numeros[i]; // Adiciona o número atual à soma total
    }
    
    return soma;
}

/**
 * Método 2: Calcula o somatório usando o método reduce (mais moderno e conciso).
 * 
 * @param {number[]} numeros Um array de números a serem somados.
 * @returns {number} O resultado da soma de todos os números.
 */
function calcularSomatorioReduce(numeros) {
    // O reduce acumula os valores da esquerda para a direita
    return numeros.reduce((acumulador, valorAtual) => acumulador + valorAtual, 0);
}

// Conjunto de números para testar
const meuConjunto = [10.5, 20.0, 5.25, 4.25, 10.0];

console.log("--- Calculadora de Somatório ---");
console.log(`Conjunto de números: [${meuConjunto.join(", ")}]`);
console.log("--------------------------------");

// Testando o método tradicional
const resultadoTradicional = calcularSomatorioTradicional(meuConjunto);
console.log(`Resultado (Método Tradicional): ${resultadoTradicional}`);

// Testando o método com reduce
const resultadoReduce = calcularSomatorioReduce(meuConjunto);
console.log(`Resultado (Método Reduce): ${resultadoReduce}`);